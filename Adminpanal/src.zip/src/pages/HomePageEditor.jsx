import { useState } from 'react';
import Layout from '../components/Layout';
import EditorHeader from '../components/editor/EditorHeader';
import SectionCard from '../components/editor/SectionCard';
import LivePreview from '../components/editor/LivePreview';
import EditorFooter from '../components/editor/EditorFooter';
import { formMap } from '../components/editor/SectionForms';
import { editorMeta, sectionList, initialContent } from '../data/editorData';
import { sectionIcons } from '../components/editor/EditorIcons';
import {
  HeroPreview, StatsPreview, ServicesPreview,
  GalleryPreview, ReviewsPreview, ValuesPreview,
} from '../components/editor/PreviewSections';
import '../styles/editor.css';

const previewMap = {
  hero:     (c) => <HeroPreview data={c.hero} stats={c.stats} />,
  stats:    (c) => <StatsPreview data={c.stats} />,
  services: (c) => <ServicesPreview data={c.services} />,
  gallery:  (c) => <GalleryPreview data={c.gallery} />,
  reviews:  (c) => <ReviewsPreview data={c.reviews} />,
  values:   (c) => <ValuesPreview data={c.values} />,
};

export default function HomePageEditor() {
  const [content, setContent]       = useState(initialContent);
  const [savedContent, setSaved]    = useState(initialContent);
  const [openId, setOpenId]         = useState('hero');
  const [mode, setMode]             = useState('draft');

  const setSection = (key, val) => setContent((c) => ({ ...c, [key]: val }));
  const toggle = (id) => setOpenId((o) => (o === id ? null : id));

  return (
    <Layout>
      <div className="ed-page">
        <EditorHeader />

        <div className="ed-grid">
          {/* ---- Left: sections ---- */}
          <div>
            <div className="ed-sechead">
              <h2>{editorMeta.sectionsTitle} <span>· {sectionList.length}</span></h2>
            </div>

            {sectionList.map((meta) => {
              const Form = formMap[meta.id];
              const Icon = sectionIcons[meta.icon];
              return (
                <SectionCard
                  key={meta.id}
                  id={meta.id}
                  icon={Icon}
                  title={meta.title}
                  subtitle={meta.subtitle}
                  open={openId === meta.id}
                  onToggle={() => toggle(meta.id)}
                >
                  <Form data={content[meta.id]} onChange={(v) => setSection(meta.id, v)} />
                </SectionCard>
              );
            })}
          </div>

          {/* ---- Right: live preview ---- */}
          <LivePreview url="saanjhbeauty.in">
            {() => (
              <div>
                {sectionList.map((meta) => {
                  const render = previewMap[meta.id];
                  return render ? <div key={meta.id}>{render(content)}</div> : null;
                })}
              </div>
            )}
          </LivePreview>
        </div>

        <EditorFooter
          mode={mode} setMode={setMode}
          onDiscard={() => setContent(savedContent)}
          onSave={() => setSaved(content)}
        />
      </div>
    </Layout>
  );
}
