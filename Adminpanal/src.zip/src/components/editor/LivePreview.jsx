import { useEffect, useRef, useState } from "react";
import { Monitor, Smartphone } from "lucide-react";

const WIDTH = { desktop: 1180, mobile: 390 };

// Website ka asli-size page virtual canvas par render hota hai, phir panel ki width ke hisaab se chhota (scale) hota hai.
// children = (device) => <Preview />
export default function LivePreview({ url, children }) {
  const [device, setDevice] = useState("desktop");
  const [m, setM] = useState({ s: 0.5, h: 0 });
  const view = useRef(null);
  const page = useRef(null);
  const W = WIDTH[device];

  useEffect(() => {
    const v = view.current, p = page.current;
    if (!v || !p) return;
    const calc = () => {
      const avail = v.clientWidth - (device === "mobile" ? 32 : 0);
      const s = Math.min(1, avail / W);
      setM({ s, h: p.offsetHeight * s });
    };
    calc();
    const ro = new ResizeObserver(calc);
    ro.observe(v);
    ro.observe(p);
    return () => ro.disconnect();
  }, [W, device]);

  return (
    <aside className="lp" aria-label="Live preview">
      <div className="lp-head">
        <span className="lp-dot" />
        <b>Live preview</b>
        <span className="lp-chip">{device === "desktop" ? "Desktop" : "Mobile"}</span>
        <div className="lp-dev" role="group" aria-label="Preview device">
          <button type="button" className={device === "desktop" ? "on" : ""} onClick={() => setDevice("desktop")} aria-label="Desktop preview"><Monitor size={20} /></button>
          <button type="button" className={device === "mobile" ? "on" : ""} onClick={() => setDevice("mobile")} aria-label="Mobile preview"><Smartphone size={20} /></button>
        </div>
      </div>

      <div className="lp-frame">
        <div className="lp-bar">
          <i style={{ background: "#c4554e" }} /><i style={{ background: "#c9a26a" }} /><i style={{ background: "#8a3b47" }} />
          <span className="lp-url">{url}</span>
        </div>
        <div className="lp-view" ref={view}>
          <div className="lp-scale" style={{ width: W * m.s, height: m.h }}>
            <div className="lp-page" ref={page} style={{ width: W, transform: `scale(${m.s})` }}>
              {children(device)}
            </div>
          </div>
        </div>
      </div>
    </aside>
  );
}
